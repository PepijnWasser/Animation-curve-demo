using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "spellcards/CircleSpraySpawner")]
public class CircleSpraySpawner : SpellCard
{
    public GameObject bulletPrefab;

    public AnimationCurve bulletXCurve;
    public AnimationCurve bulletYCurve;
    public AnimationCurve sprayAmountCurve;
    public AnimationCurve difficultyRampCurve;

    public float spawnRate;

    int bulletCount = 0;

    float bulletSpawnTimer;

    float modifiedSpawnRate;

    int amountOfSprays;

    public override void DestroyCard(GameObject gameObject)
    {
        
    }

    public override void Initialize(GameObject gameObject)
    {
        bulletCount = 0;
        bulletSpawnTimer = 0;

        int difficulty = GameObject.FindGameObjectWithTag("GameData").GetComponent<GameData>().difficulty;
        modifiedSpawnRate = spawnRate / difficultyRampCurve.Evaluate(difficulty);
        amountOfSprays = (int)sprayAmountCurve.Evaluate(difficulty);

        gameObject.transform.position = new Vector3(0, 50, 0);
    }

    public override void UpdateCard(GameObject gameObject)
    {
        bulletSpawnTimer += Time.deltaTime;
        if (bulletSpawnTimer > modifiedSpawnRate)
        {
            bulletSpawnTimer = 0;
            bulletCount += 1;

            float posX = bulletXCurve.Evaluate(bulletCount);
            float posY = bulletYCurve.Evaluate(bulletCount);

            float degreesPerSpray = 360 / amountOfSprays;
            for(int i = 1; i <= amountOfSprays; i++)
            {
                float rot = degreesPerSpray * i;

                Vector3 newRotation = new Vector3(posX, posY, 0);
                newRotation = Quaternion.Euler(0, 0, rot) * newRotation;

                GameObject bullet = Instantiate(bulletPrefab, gameObject.transform.position, Quaternion.identity);

                bullet.transform.up = newRotation;

                bullet.GetComponent<Bullet>().bulletSpeed = 25;
            }       
        }
    }
}
