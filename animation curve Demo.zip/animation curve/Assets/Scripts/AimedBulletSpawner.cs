using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "spellcards/AimedBulletSpawner")]
public class AimedBulletSpawner : SpellCard
{
    public GameObject bulletPrefab;
    public AnimationCurve bulletAmountCurve;
    public AnimationCurve bulletSpeedCurve;
    public AnimationCurve bulletSpawnFrequencyCurve;
    public AnimationCurve bulletSetFrequencyCurve;
    public AnimationCurve positionChangeTimerCurve;

    int bulletAmount;
    int bulletSpeed;
    float bulletSpawnFrequency;
    float bulletSetFrequency;
    float positionChangeTimer;

    GameObject player;

    public Vector2 horizontalConstraints;
    public Vector2 verticalConstraints;


    float setTimer;
    float bulletTimer;
    float changePositionTimer;

    bool shootingBullets = false;
    int bulletsSpawned = 0;


    public override void Initialize(GameObject gameObject)
    {
        setTimer = 0;
        bulletTimer = 0;
        changePositionTimer = 0;
        shootingBullets = false;
        bulletsSpawned = 0;

        player = GameObject.FindGameObjectWithTag("MyPlayer");

        int difficulty = GameObject.FindGameObjectWithTag("GameData").GetComponent<GameData>().difficulty;
        bulletAmount = (int)bulletAmountCurve.Evaluate(difficulty);
        bulletSpeed = (int)bulletSpeedCurve.Evaluate(difficulty);
        bulletSpawnFrequency = bulletSpawnFrequencyCurve.Evaluate(difficulty);
        bulletSetFrequency = bulletSetFrequencyCurve.Evaluate(difficulty);
        positionChangeTimer = positionChangeTimerCurve.Evaluate(difficulty);
    }

    public override void UpdateCard(GameObject gameObject)
    {
        setTimer += Time.deltaTime;
        if (setTimer > bulletSetFrequency)
        {
            bulletsSpawned = 0;
            setTimer = 0;
            shootingBullets = true;
        }
        if (shootingBullets)
        {
            SpawnSet(gameObject);
        }

        changePositionTimer += Time.deltaTime;
        if (changePositionTimer > positionChangeTimer)
        {
            changePositionTimer = 0;
            GenerateNewPosition(gameObject);
        }
    }

    void SpawnSet(GameObject parent)
    {
        bulletTimer += Time.deltaTime;
        if (bulletTimer > bulletSpawnFrequency)
        {
            GameObject bullet = Instantiate(bulletPrefab, parent.transform.position, Quaternion.identity);

            Vector3 deltaVec = parent.transform.position - player.transform.position;
            bullet.transform.up = -deltaVec;
            bullet.GetComponent<Bullet>().bulletSpeed = bulletSpeed;

            bulletTimer = 0;
            bulletsSpawned += 1;
            if (bulletsSpawned == bulletAmount)
            {
                shootingBullets = false;
            }
        }
    }

    void GenerateNewPosition(GameObject parent)
    {
        parent.transform.position = new Vector3(Random.Range(horizontalConstraints.x, horizontalConstraints.y), Random.Range(verticalConstraints.x, verticalConstraints.y), 0);
    }

    public override void DestroyCard(GameObject gameObject)
    {
        
    }
}
