using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "spellcards/MovingBulletSpawner")]
public class MovingBulletSpawner : SpellCard
{
    public GameObject bulletPrefab;
    public AnimationCurve bulletAmountCurve;
    public AnimationCurve bulletSpawnFrequencyCurve;
    public AnimationCurve bulletSetFrequencyCurve;
    public AnimationCurve bulletPositionXCurve;
    public AnimationCurve bulletPositionYCurve;

    int bulletAmount;
    float bulletSpawnFrequency;
    float bulletSetFrequency;

    float setTimer;
    float bulletTimer;

    public bool creatingSet = false;
    public int bulletsSpawned = 0;

    List<GameObject> bullets = new List<GameObject>();
    List<float> bulletAges = new List<float>();

    public override void Initialize(GameObject gameObject)
    {
        setTimer = 0;
        bulletTimer = 0;
        creatingSet = false;
        bulletsSpawned = 0;

        int difficulty = GameObject.FindGameObjectWithTag("GameData").GetComponent<GameData>().difficulty;
        bulletAmount = (int)bulletAmountCurve.Evaluate(difficulty);
        bulletSpawnFrequency = bulletSpawnFrequencyCurve.Evaluate(difficulty);
        bulletSetFrequency = bulletSetFrequencyCurve.Evaluate(difficulty);
    }

    public override void UpdateCard(GameObject gameObject)
    {
        setTimer += Time.deltaTime;
        if (setTimer > bulletSetFrequency)
        {
            bulletsSpawned = 0;
            setTimer = 0;
            creatingSet = true;
        }
        if (creatingSet)
        {
            SpawnSet(gameObject);
        }
        UpdateBullets();
    }

    void SpawnSet(GameObject parent)
    {
        bulletTimer += Time.deltaTime;
        if (bulletTimer > bulletSpawnFrequency)
        {
            GameObject bullet = Instantiate(bulletPrefab, parent.transform.position, Quaternion.identity);
            bullets.Add(bullet);
            bulletAges.Add(0);

            bulletTimer = 0;
            bulletsSpawned += 1;
            if (bulletsSpawned == bulletAmount)
            {
                creatingSet = false;
            }
        }
    }

    void UpdateBullets()
    {
        RemoveBadEntries();

        int count = bulletAges.Count;

        for(int i = 0; i < count; i++)
        {
            bulletAges[i] += Time.deltaTime;
            bullets[i].transform.position = new Vector2(bulletPositionXCurve.Evaluate(bulletAges[i]), bulletPositionYCurve.Evaluate(bulletAges[i]));
        }
    }

    void RemoveBadEntries()
    {
        int count = bulletAges.Count;
        List<int> bulletsToRemove = new List<int>();

        for (int i = 0; i < count; i++)
        {
            if (bullets[i] == null)
            {
                bulletsToRemove.Add(i);
            }
        }

        foreach (int i in bulletsToRemove)
        {
            bullets.RemoveAt(i);
            bulletAges.RemoveAt(i);
        }
    }

    public override void DestroyCard(GameObject gameObject)
    {
        RemoveBadEntries();

         int count = bulletAges.Count;

        for (int i = 0; i < count; i++)
        {
            Destroy(bullets[i]);
        }
    }
}
