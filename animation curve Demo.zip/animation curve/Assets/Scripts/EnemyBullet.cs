using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBullet : Bullet
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "MyPlayer")
        {
            Debug.Log("hit player");
            Destroy(this.gameObject);
        }
    }
}
