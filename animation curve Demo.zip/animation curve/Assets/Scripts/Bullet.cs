using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Bullet : MonoBehaviour
{
    public float bulletSpeed;
    public Vector2 horizontalConstraints;
    public Vector2 verticalConstraints;

    void Update()
    {
        this.transform.position = this.transform.position + transform.up * bulletSpeed * Time.deltaTime;  
        
        if(transform.position.x > horizontalConstraints.y || transform.position.x < horizontalConstraints.x ||
            transform.position.y > horizontalConstraints.y || transform.position.y < horizontalConstraints.x)
        {
            Destroy(this.gameObject);
        }
    }
}
