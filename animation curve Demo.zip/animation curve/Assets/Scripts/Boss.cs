using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Boss : MonoBehaviour
{
    public AnimationCurve healthCurve;

    public List<SpellCard> spellCards;

    int health;

    public float spellCardSwitchTimer;
    float timer;
    SpellCard activeSpellCard;


    private void Start()
    {
        int difficulty = GameObject.FindGameObjectWithTag("GameData").GetComponent<GameData>().difficulty;
        health = (int)healthCurve.Evaluate(difficulty);

        activeSpellCard = spellCards[Random.Range(0, spellCards.Count)];
        activeSpellCard.Initialize(this.gameObject);
    }

    void Update()
    {
        timer += Time.deltaTime;
        if(timer > spellCardSwitchTimer)
        {
            timer = 0;
            activeSpellCard = spellCards[Random.Range(0, spellCards.Count)];
            activeSpellCard.Initialize(this.gameObject);
            foreach(SpellCard spellCard in spellCards)
            {
                if(spellCard != activeSpellCard)
                {
                    spellCard.DestroyCard(this.gameObject);
                }
            }
        }
        activeSpellCard.UpdateCard(this.gameObject);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.tag == "PlayerBullet")
        {
            health = health - 1;
            if(health <= 0)
            {
                GameObject.FindGameObjectWithTag("GameStatus").gameObject.GetComponent<Text>().text = "Victory";
                foreach(SpellCard spellCard in spellCards)
                {
                    spellCard.DestroyCard(this.gameObject);
                }
                Destroy(this.gameObject);
            }
        }
    }
}
