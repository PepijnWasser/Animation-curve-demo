using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerControls : MonoBehaviour
{
    public float moveSpeed = 2;

    public Vector2 horizontalBoundries;
    public Vector2 verticalBoundries;

    public Rigidbody2D rigidBody;

    Vector3 moveDir;

    public GameObject playerBullet;

    public float bulletShootSpeed;
    float bulletTimer = 0;

    private void FixedUpdate()
    {
        rigidBody.MovePosition(transform.position + moveDir * moveSpeed * Time.fixedDeltaTime);
    }

    void Update()
    {
        float moveX = 0;
        float moveY = 0;

        if (Input.GetKey(KeyCode.D))
        {
            moveX = 1f;
        }
        if (Input.GetKey(KeyCode.A))
        {
            moveX = -1f;
        }
        if (Input.GetKey(KeyCode.W))
        {
            moveY = 1f;
        }
        if (Input.GetKey(KeyCode.S))
        {
            moveY = -1f;
        }
        moveDir = new Vector3(moveX, moveY).normalized;

        bulletTimer += Time.deltaTime;

        if (Input.GetMouseButton(0) && bulletTimer > bulletShootSpeed)
        {
            bulletTimer = 0;
            Instantiate(playerBullet, this.transform.position, this.transform.rotation);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag == "Bullet" || collision.gameObject.tag == "Enemy")
        {
            Debug.Log("Game Over");
            GameObject.FindGameObjectWithTag("GameStatus").gameObject.GetComponent<Text>().text = "Game Over";
        }
    }
}
